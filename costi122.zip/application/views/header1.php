<div class="wrapper row1" style="background-color: #255f7a; height: 65px;">
    <header id="header" class="hoc clear">
        <!-- ################################################################################################ -->
        <div id="logo" class="fl_left">
            <div style="font-size: 25px;">PUBLIC OBSERVATORY SYSTEM</div>
            
        </div>
        <!-- ################################################################################################ -->
        <div id="mainav" class="fl_right">
            <ul class="clear">
                <li><a class="drop active" href="#">Home</a>
                    <ul>
                        <li><a href="<?php echo base_url().'main'?>#map">Map</a></li>
                        <li><a href="<?php echo base_url().'main'?>#pc">Issue Categories</a></li>
                        <li><a href="<?php echo base_url().'main'?>#pyp">Post Your Problem</a></li>
                    </ul>
                </li>
                <li>
                    <a  href="<?php echo base_url().'question'?>">Issue</a>
                </li>
            </ul>
        </div>
        <!-- ################################################################################################ -->
    </header>
</div>