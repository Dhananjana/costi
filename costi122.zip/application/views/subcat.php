<?=$nav?>
<div class="wrapper row2">
    <div id="breadcrumb" class="hoc clear">
        <!-- ################################################################################################ -->
        <ul>
            <li><a href="<?php echo base_url().'main'?>">Home</a></li>
            <li><a href="">Sub Categories</a></li>
        </ul>
        <!-- ################################################################################################ -->
    </div>
</div>
<br>
<div style="height: 1100px">
<div class="col-lg-5" id="one" style="margin-left: 30%">
    <h5>Infrastructure</h5>
    <hr>
    <ol>
        <li>Laboratory/Incubator/Central facility</li>
        <li>Access to High Tech Instrument</li>
        <li>After Sales services</li>
        <li>Repair & Maintenance of instruments</li>
        <li>Other</li>
    </ol>
</div>
<br>
<div class="col-lg-5" id="two" style="margin-left: 30%">
    <h5>Funds</h5>
    <hr>
    <ol>
        <li>Find a research grant</li>
        <li>Find a technology/equipment grant</li>
        <li>Travel grantes</li>
        <li>Find a investor/venture capital provider</li>
        <li>Other</li>
    </ol>
</div>
<br>
<div class="col-lg-5" id="three" style="margin-left: 30%">
    <h5>Human resource and skill development</h5>
    <hr>
    <ol>
        <li>Scholarships</li>
        <li>Training Local/foreign</li>
        <li>Workshops/foreign exposure</li>
        <li>Find Literature</li>
        <li>Find expertise knowledge/consultant</li>
        <li>Lack of incentives and merit system</li>
        <li>Lack of qualifield personals</li>
        <li>Lack of mecanism to retain competent personnel</li>
        <li>Other</li>
    </ol>
</div>
<br>
<div class="col-lg-5" id="four" style="margin-left: 30%">
    <h5>Administrative and Procurement</h5>
    <hr>
    <ol>
        <li>Undue delay in customs clearing</li>
        <li>Difficulties with overseas purchases and payments</li>
        <li>Inefficient and complicated procurement procedures</li>
        <li>Lengthy administrative procedures</li>
        <li>Other</li>
    </ol>
</div><br>
    <div class="col-lg-5" id="five" style="margin-left: 30%">
        <h5>Intellectual Property Management</h5>
        <hr>
        <ol>
            <li>patent</li>
            <li>Industrial Design</li>
            <li>Trademarks</li>
            <li>Other</li>
        </ol>
    </div><br>
</div>