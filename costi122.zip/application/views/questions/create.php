<div class="col-lg-9"></div>
<div class="col-lg-3">
    <a href="<?php echo base_url().'Main/loadform';?>" class="btn btn-info" >
      Post a Problem
    </a>
  <br> <br> <br>
</div>
