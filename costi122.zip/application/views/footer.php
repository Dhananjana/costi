<div class="wrapper row4 " style="background-color: #255656;height: 200px;padding-top: 5px">
    <footer id="footer" class=" clear">
        <div class="social-icon col-lg-offset-3">
            <div class="col-lg-6">
                <ul class="social-network">
                    <li><a href="#" class="fb tool-tip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#" class="twitter tool-tip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#" class="gplus tool-tip" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="#" class="linkedin tool-tip" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="#" class="ytube tool-tip" title="You Tube"><i class="fa fa-youtube-play"></i></a></li>
                </ul>
            </div>
        </div>
    </footer>
</div>
<div class="wrapper row5">
    <div id="copyright" class="hoc clear">
        <p class="fl_left">Copyright &copy; 2018 - All Rights Reserved - <a href="https://costi.gov.lk">Costi</a></p>
        <p class="fl_right">Created by <a target="_blank" href="https://www.facebook.com/TeamForesight1/" title="Foresight">Team Foresight</a></p>
    </div>
</div>

<a id="backtotop" href="#top"><i class="fa fa-chevron-up"></i></a>
<!-- JAVASCRIPTS -->
<script src="<?php echo base_url().'assets/js/jquery-2.1.1.min.js';?>"></script>
<script src="<?php echo base_url().'assets/js/bootstrap.min.js';?>"></script>
<script src="<?php echo base_url().'newhome/layout/scripts/jquery.min.js';?>"></script>
<script src="<?php echo base_url().'newhome/layout/scripts/jquery.backtotop.js';?>"></script>
<script src="<?php echo base_url().'newhome/layout/scripts/jquery.mobilemenu.js';?>"></script>
<script src="<?php echo base_url().'newhome/layout/scripts/map.js';?>"></script>
</body>
</html>